<?php
$sql = "SELECT * from pages";
$res = mysqli_query($connection, $sql);
$pages = mysqli_fetch_all($res, MYSQLI_ASSOC);
?>

<div id="page-wrapper">
    <a href="/admins/?action=add_page" class="btn btn-sm btn-success">добавить статью</a>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">Название</th>
            <th scope="col">Действие</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($pages as $page):?>
        <tr>
            <td><?=$page['title']?></td>
            <td>
                <a href="/adminka/?action=edit_page&id=<?=$page['id']?>">редактировать</a> </td>
                <a href="/adminka/?action=edit_page&id=<?=$page['id']?>">удалить</a> </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>