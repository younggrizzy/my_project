<?php
if(isset($_GET['id']) && !empty($_GET['id']) && $_GET['action'] == 'edit_page'){
    $id = $_GET['id'];
    $stmt = mysqli_prepare($connection,"SELECT * from pages WHERE id = ? ");
    mysqli_stmt_bind_param($stmt, 'd', $id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $page = mysqli_fetch_assoc($res);
}

$sql = "Select * from category";
$result = mysqli_query($connection, $sql);
$categories = mysqli_fetch_all($result, MYSQLI_ASSOC);
//var_dump($categories);

$url = isset($page['id']) ? '/admins/?action=update_page&id=' . $page['id'] : '/admins/?action=save_page';
?>
<div id="page-wrapper">
    <div class="row">
        <form class="form" method="post" action="<?=$url?>" enctype="multipart/form-data">
            <div class="container-fluid">
                <div class="row">

                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-close">
                                <div class="dropdown">
                                    <button type="button" id="closeCard5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-ellipsis-v"></i></button>
                                    <div aria-labelledby="closeCard5" class="dropdown-menu dropdown-menu-right has-shadow"><a href="#" class="dropdown-item remove"> <i class="fa fa-times"></i>Close</a><a href="#" class="dropdown-item edit"> <i class="fa fa-gear"></i>Edit</a></div>
                                </div>
                            </div>
                            <div class="card-header d-flex align-items-center">
                                <h3 class="h4">All form elements</h3>
                            </div>
                            <div class="card-body">
                                <form class="form-horizontal">
                                    <div class="form-group row">
                                        <label class="col-sm-3 form-control-label">title</label>
                                        <div class="col-sm-9">
                                            <input class="form-control" name="title" value="<?=$page['title'] ?? '' ?>">
                                        </div>
                                    </div>
                                    <div class="line"></div>
                                    <div class="form-group row">
                                        <label class="col-sm-3 form-control-label">img</label>
                                        <div class="col-sm-9">
                                            <input type="file" class="form-control" name="page_img">
                                        </div>
                                    </div>
                                    <div class="line"></div>
                                    <div class="form-group row">
                                        <label class="col-sm-3 form-control-label">content</label>
                                        <div class="col-sm-9">
                                            <input class="form-control" name="content" value="<?=$page['content'] ?? '' ?>">
                                        </div>
                                    </div>
                                    <div class="line"></div>
                                    <div class="form-group row">
                                        <label class="col-sm-3 form-control-label">author</label>
                                        <div class="col-sm-9">
                                            <input class="form-control" name="author" value="<?=$page['author'] ?? '' ?>">
                                        </div>
                                    </div>
                                    <div class="line"></div>
                                    <div class="form-group row">
                                        <label class="col-sm-3 form-control-label">category</label>
                                        <div class="col-sm-9">
                                            <select name="category" class="form-control">
                                                <?php foreach ($categories as $category):
                                                    $selected = '';
                                                if(isset($page['category']) && $page['category'] == $category['id']){
                                                    $selected = 'selected';
                                                }
                                                    ?>
                                                <option value="<?=$category['category_id']?>" <?=$selected?>><?=$category['category']?></option>
                                                <?php endforeach;?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="line"></div>
                                    <button>save</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>