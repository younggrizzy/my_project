<?php
if (isset($_GET['id_brand']) && !empty($_GET['id']) && $_GET['action'] == 'edit_product') {
    $id = $_GET['id_brand'];
    $stmt = mysqli_prepare($connection, "SELECT * from brand WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "d", $id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $page = mysqli_fetch_assoc($res);
}

$sql = "SELECT * FROM brand";
$res = mysqli_query($connection, $sql);
$categories = mysqli_fetch_all($res, MYSQLI_ASSOC);

$req = "SELECT * FROM brand";
$resp = mysqli_query($connection, $req);
$brands = mysqli_fetch_all($resp, MYSQLI_ASSOC);


$url = isset($page['id']) ? '/admins/?action=update_product&id=' . $page['id'] : '/admins/?action=save_product';

?>

    <body>
    <section>
        <div class="mainpanel">
            <div class="pageheader">
                <div class="media">
                    <div class="pageicon pull-left">
                        <i class="fa fa-pencil"></i>
                    </div>
                </div>
            </div>

            <div class="contentpanel">



                            <div class="panel-body nopadding">

                                <form class="form-horizontal form-bordered" role="form" method="post"
                                      action="<?= $url ?>" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Brand</label>
                                        <div class="col-sm-8">
                                            <select name="brand" class="form-control">
                                                <?php foreach ($brands as $brand):
                                                    $selected = '';
                                                    if (isset($page['id_brand']) && $page['id_brand'] == $brand['id']) {
                                                        $selected = 'selected';
                                                    }
                                                    ?>
                                                    <option value="<?= $brand['id'] ?>" <?=$selected ?> > <?= $brand['name'] ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div><!-- form-group -->

                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Size</label>
                                        <div class="col-sm-8">
                                            <input type="text" placeholder="Default Input" name="size"
                                                   value="<?= $page['size'] ?? '' ?>"
                                                   class="form-control"/>
                                        </div>
                                    </div><!-- form-group -->

                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Cost</label>
                                        <div class="col-sm-8">
                                            <input type="text" placeholder="Default Input" name="cost"
                                                   value="<?= $page['cost'] ?? '' ?>"
                                                   class="form-control"/>
                                        </div>
                                    </div><!-- form-group -->

                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Product name</label>
                                        <div class="col-sm-8">
                                        <textarea type="text" placeholder="Default Input" rows="3" name="name"
                                                  class="form-control"> <?= $page['description'] ?? '' ?> </textarea>
                                        </div>
                                    </div><!-- form-group -->

                                    <div class="form-group">
                                        <label class="col-sm-4 control-label" for="disabledinput">Image</label>
                                        <div class="col-sm-8">
                                            <input placeholder="Disabled Input" id="disabledinput"
                                                   name="product_img" type="file" value="<?= $page['img'] ?? '' ?>"
                                                   class="form-control"/>
                                        </div>
                                    </div><!-- form-group -->

                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">In stock</label>
                                        <div class="col-sm-8">
                                            <input type="text" placeholder="Default Input" name="in_stock"
                                                   value="<?= $page['availability'] ?? '' ?>"
                                                   class="form-control"/>
                                        </div>
                                    </div><!-- form-group -->

                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Category</label>
                                        <div class="col-sm-8">
                                            <select name="category" class="form-control">
                                                <?php foreach ($brands as $brand):
                                                    $selected = '';
                                                    if (isset($page['id_brand']) && $page['id_brand'] == $brand['id']) {
                                                        $selected = 'selected';
                                                    }
                                                    ?>
                                                    <option value="<?= $brand['id'] ?>" <?=$selected ?> > <?= $brand['grops'] ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <button>save</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    </body>
    </html>

