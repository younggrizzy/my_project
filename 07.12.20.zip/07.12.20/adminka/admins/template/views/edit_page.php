<?php

require_once 'add_page.php';