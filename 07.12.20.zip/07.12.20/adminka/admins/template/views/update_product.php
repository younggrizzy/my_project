<div class="mainpanel">
    <?php
    $ids = $_GET['id_brand'];
    $brand = $_POST['name'];
    $size = $_POST['size'];
    $cost = $_POST['cost'];
    $description = $_POST['description'];
    $availability = $_POST['availability'];
    $grops = $_POST['grops'];
    if (isset($_FILES) && $_FILES['img']['size'] > 0) {
        $imgUrl = '/images/' . $_FILES['img']['name'];
        $stmt = mysqli_prepare($connection, "UPDATE brand SET  id_brand = ? , size = ? , cost = ?, description = ?, img = ?, availability = ?, grops = ? WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "dsddssss", $ids, $brand, $size, $cost, $description, $imgUrl, $availability, $grops);
        mysqli_stmt_execute($stmt);
    } else {
        $stmt = mysqli_prepare($connection, "UPDATE brand SET  id_brand = ? , size = ? , cost = ?, description = ?, availability = ?, grops = ? WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "dsddsss", $ids,$brand, $size, $cost, $description, $availability, $grops);
        mysqli_stmt_execute($stmt);
    }

    ?>


    <h4 class="panel-title">Page successfully updated</h4>
    <a href="/admin/?action=product_list_page">Назад</a>

</div>
