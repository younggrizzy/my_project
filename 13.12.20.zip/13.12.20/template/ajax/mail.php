<?php
    $email = $_POST['email'];
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $massage = $_POST['massage'];

    $subject = "=?utf-8?B?".base64_encode("Сообщение с сайта")."?=";
    $headers = "From: $email\r\n Replay-to: $email\r\n Content-type: text/html; charset=utf-8\r\n";

    $success = mail("qwerty@gmail.com", $subject, $message);
    echo $success;
?>