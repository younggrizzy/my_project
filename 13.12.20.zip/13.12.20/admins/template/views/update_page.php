<?php
var_dump($_POST);
$_POST['content'] = 'new content';
$sql = "UPDATE pages SET ";
foreach ($_POST as $key => $value){
    $sql .= "{$key} = '$value',";
}
$sql = substr($sql, 0, -1);
$sql.='where id='.$_GET['id'];
echo $sql;
//update pages set title='new title', img='new img url', content='new content', author='new author', category='new category';
//mysqli_query($connection, $sql);