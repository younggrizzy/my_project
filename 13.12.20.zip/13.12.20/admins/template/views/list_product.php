<?php
$sql = "SELECT * from brand";
$res = mysqli_query($connection, $sql);
$pages = mysqli_fetch_all($res, MYSQLI_ASSOC);
?>

    <div class="mainpanel">
        <div class="contentpanel">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th scope="col">Название товара</th>
                    <th scope="col">Действия</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($pages as $page): ?>
                    <tr>
                        <td><?= $page['name'] ?></td>
                        <td>
                            <a href="/admins/?action=edit_product&id=<?= $page['id_brand'] ?>">Редактировать</a>
                            <a href="/admins/?action=delete_product&id=<?= $page['id_brand'] ?>">Удалить</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php
