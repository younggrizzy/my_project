<?php
$sql = "DELETE FROM brand WHERE id = '{$_GET['id']}'  LIMIT 1";
mysqli_query($connection, $sql);
?>

    <div class="mainpanel">
        <h4 class="panel-title">Page successfully deleted</h4>
        <a href="/admins/?action=list_product">Назад</a>
    </div>

