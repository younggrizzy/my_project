<div class="mainpanel">

    <?php
    if (!empty($_POST)) {
        echo '<h4>Article uploaded</h4>';
        if ($_FILES['img']['size'] > 0) {
            $imgUrl = '/images/' . $_FILES['img']['name'];
            move_uploaded_file($_FILES['img']['tmp_name'],
                BASE_PATH . '../images/' . $_FILES['img']['name']);
        }
    }
    $brand = $_POST['name'];
    $size = $_POST['size'];
    $cost = $_POST['cost'];
    $description = $_POST['description'];
    $availability = $_POST['availability'];
    $grops = $_POST['grops'];
    $stmt = mysqli_prepare($connection, "INSERT INTO brand (`name`, `size`, `cost`, `description`, `img`, `availability`, `grops`)
VALUES (?, ?, ?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "sddssss", $brand,  $size, $cost, $description, $imgUrl, $availability, $grops);
    mysqli_stmt_execute($stmt);
    ?>
</div>
<?php
